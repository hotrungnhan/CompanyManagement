package com.example.companymanagement.viewcontroller.fragment.mainproject

import androidx.lifecycle.ViewModel

class MainProjectViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}