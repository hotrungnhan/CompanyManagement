package com.example.companymanagement.utils

enum class DrawableEnum(val value: Int) {
    Left(0), Right(2), Bottom(3), Top(1)
}