package com.example.companymanagement.viewcontroller.fragment.mainworkspace

import androidx.lifecycle.ViewModel

class MainWorkspaceViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}